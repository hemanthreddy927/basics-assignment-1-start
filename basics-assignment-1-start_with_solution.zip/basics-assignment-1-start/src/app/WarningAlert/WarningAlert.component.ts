import {Component} from '@angular/core';

@Component({
    selector:'Warning-Alert',
    templateUrl:'WarningAlert.component.html',
    styleUrls:['WarningAlert.component.css']

})

export class WarningAlertComponent{

}